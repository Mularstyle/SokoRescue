import { describe, expect, it } from 'vitest';
import solc from 'solc';
import { readFile } from 'node:fs/promises';

describe('SokoChain contract artifact', () => {
  it('compiles for Cancun and exposes the required public interface', async () => {
  const source = await readFile('contracts/SokoChain.sol', 'utf8');
  const input = {
    language: 'Solidity',
    sources: { 'SokoChain.sol': { content: source } },
    settings: {
      evmVersion: 'cancun',
      outputSelection: { '*': { '*': ['abi', 'evm.bytecode.object'] } },
    },
  };
  const output = JSON.parse(solc.compile(JSON.stringify(input)));
  const errors = (output.errors ?? []).filter((error: { severity: string }) => error.severity === 'error');
  expect(errors).toEqual([]);
    const artifact = output.contracts['SokoChain.sol'].SokoChain;
    const names = artifact.abi.filter((item: { type: string }) => item.type === 'function').map((item: { name: string }) => item.name);
    expect(names).toEqual(expect.arrayContaining(['submitSolution', 'bestMoves', 'globalBestMoves', 'globalBestPlayer']));
    expect(artifact.evm.bytecode.object.length).toBeGreaterThan(0);
  });
});
