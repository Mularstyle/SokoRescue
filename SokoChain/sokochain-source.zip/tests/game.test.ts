import { describe, expect, it } from 'vitest';
import { INITIAL_STATE, applyMove, replayMoves } from '../src/game';

describe('SokoChain game rules', () => {
  it('solves the level with the canonical six-move route', () => {
    const result = replayMoves([0, 1, 1, 2, 1, 0]);
    expect(result.solved).toBe(true);
    expect(result.moves).toBe(6);
    expect(result.box).toEqual({ x: 4, y: 2 });
  });

  it('does not move through an outer wall', () => {
    const result = applyMove(INITIAL_STATE, 3);
    expect(result).toEqual(INITIAL_STATE);
  });

  it('does not move through an internal wall', () => {
    const result = replayMoves([0, 1, 0]);
    expect(result.player).toEqual({ x: 2, y: 3 });
    expect(result.moves).toBe(2);
  });

  it('does not push a box into a wall', () => {
    const trapped = { ...INITIAL_STATE, player: { x: 3, y: 4 }, box: { x: 3, y: 5 } };
    const result = applyMove(trapped, 2);
    expect(result).toEqual(trapped);
  });

  it('rejects unknown move values', () => {
    expect(() => replayMoves([4])).toThrow('Invalid move');
  });
});
