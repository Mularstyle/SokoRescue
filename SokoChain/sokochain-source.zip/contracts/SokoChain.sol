// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract SokoChain {
    uint8 public constant MAX_MOVES = 64;

    mapping(address => uint8) public bestMoves;
    uint8 public globalBestMoves;
    address public globalBestPlayer;
    uint256 public playerCount;
    uint256 public totalValidSubmissions;

    event SolutionSubmitted(address indexed player, uint8 moves, bool personalBest, bool globalBest);

    function submitSolution(uint8[] calldata moves) external {
        require(moves.length > 0, "Unsolved");
        require(moves.length <= MAX_MOVES, "Too many moves");

        uint8 playerX = 1;
        uint8 playerY = 4;
        uint8 boxX = 3;
        uint8 boxY = 3;

        for (uint256 i = 0; i < moves.length; i++) {
            uint8 direction = moves[i];
            require(direction <= 3, "Invalid direction");

            int8 dx;
            int8 dy;
            if (direction == 0) dy = -1;
            else if (direction == 1) dx = 1;
            else if (direction == 2) dy = 1;
            else dx = -1;

            uint8 nextX = uint8(int8(playerX) + dx);
            uint8 nextY = uint8(int8(playerY) + dy);
            require(!_isWall(nextX, nextY), "Invalid move");

            if (nextX == boxX && nextY == boxY) {
                uint8 pushedX = uint8(int8(boxX) + dx);
                uint8 pushedY = uint8(int8(boxY) + dy);
                require(!_isWall(pushedX, pushedY), "Invalid push");
                boxX = pushedX;
                boxY = pushedY;
            }

            playerX = nextX;
            playerY = nextY;
        }

        require(boxX == 4 && boxY == 2, "Unsolved");

        totalValidSubmissions++;
        uint8 score = uint8(moves.length);
        uint8 previousBest = bestMoves[msg.sender];
        bool personalBest = previousBest == 0 || score < previousBest;
        if (personalBest) {
            if (previousBest == 0) playerCount++;
            bestMoves[msg.sender] = score;
        }

        bool globalBest = globalBestMoves == 0 || score < globalBestMoves;
        if (globalBest) {
            globalBestMoves = score;
            globalBestPlayer = msg.sender;
        }

        emit SolutionSubmitted(msg.sender, score, personalBest, globalBest);
    }

    function _isWall(uint8 x, uint8 y) private pure returns (bool) {
        if (x == 0 || y == 0 || x == 6 || y == 6) return true;
        return y == 2 && (x == 2 || x == 3);
    }
}
