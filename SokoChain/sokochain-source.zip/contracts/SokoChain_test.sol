// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "remix_tests.sol";
import "./SokoChain.sol";

contract SokoChainTest {
    SokoChain private game;

    function beforeEach() public {
        game = new SokoChain();
    }

    function testCanonicalSolution() public {
        uint8[] memory moves = new uint8[](6);
        moves[0] = 0; moves[1] = 1; moves[2] = 1;
        moves[3] = 2; moves[4] = 1; moves[5] = 0;
        game.submitSolution(moves);
        Assert.equal(uint256(game.bestMoves(address(this))), 6, "personal best should be six");
        Assert.equal(uint256(game.globalBestMoves()), 6, "global best should be six");
    }

    function testLongerSolutionDoesNotReplaceBest() public {
        uint8[] memory best = new uint8[](6);
        best[0] = 0; best[1] = 1; best[2] = 1;
        best[3] = 2; best[4] = 1; best[5] = 0;
        game.submitSolution(best);

        uint8[] memory longer = new uint8[](8);
        longer[0] = 0; longer[1] = 1; longer[2] = 1; longer[3] = 2;
        longer[4] = 3; longer[5] = 1; longer[6] = 1; longer[7] = 0;
        game.submitSolution(longer);
        Assert.equal(uint256(game.bestMoves(address(this))), 6, "longer route must not replace best");
    }

    function testRejectsBlockedMove() public {
        uint8[] memory moves = new uint8[](1);
        moves[0] = 3;
        try game.submitSolution(moves) {
            Assert.ok(false, "walking into outer wall must revert");
        } catch {
            Assert.ok(true, "blocked move reverted");
        }
    }

    function testRejectsUnsolvedRoute() public {
        uint8[] memory moves = new uint8[](2);
        moves[0] = 0; moves[1] = 1;
        try game.submitSolution(moves) {
            Assert.ok(false, "unsolved route must revert");
        } catch {
            Assert.ok(true, "unsolved route reverted");
        }
    }

    function testRejectsInvalidDirection() public {
        uint8[] memory moves = new uint8[](1);
        moves[0] = 4;
        try game.submitSolution(moves) {
            Assert.ok(false, "unknown direction must revert");
        } catch {
            Assert.ok(true, "unknown direction reverted");
        }
    }

    function testRejectsMoreThan64Moves() public {
        uint8[] memory moves = new uint8[](65);
        try game.submitSolution(moves) {
            Assert.ok(false, "oversized route must revert");
        } catch {
            Assert.ok(true, "oversized route reverted");
        }
    }
}
