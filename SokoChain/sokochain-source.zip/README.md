# SokoChain

เกม Sokoban หนึ่งด่านสำหรับ Avalanche Fuji และ The Grotto ผู้เล่นแก้เกมใน browser แล้วส่งลำดับการเดินหนึ่งธุรกรรมให้ smart contract ตรวจทุกก้าว

## รันในเครื่อง

```bash
npm install
copy .env.example .env
npm run dev
```

ก่อนเปิดการส่งคะแนน ให้แก้ `VITE_CONTRACT_ADDRESS` ใน `.env` เป็น address ที่ deploy จริงบน Fuji

## Deploy contract ด้วย Remix

1. เปิด `contracts/SokoChain.sol` ใน Remix และตั้ง Solidity compiler เป็น `0.8.30` พร้อม EVM Version `cancun`.
2. รัน `contracts/SokoChain_test.sol` ผ่าน Solidity Unit Testing plugin.
3. เชื่อม Core Wallet ที่อยู่บน Avalanche Fuji C-Chain แล้ว deploy `SokoChain`.
4. ใส่ contract address ใน `.env` แล้วรัน `npm run build` ใหม่.

## เผยแพร่บน Grotto

อัปโหลดเนื้อหาภายใน `dist/` โดยให้ `index.html` อยู่ที่ root ของ zip. เกมอ่านชื่อผ่าน Grotto Runtime SDK และยังเล่นแบบ Guest ได้เมื่อ SDK ไม่พร้อม

หาก Core ไม่เปิดจาก iframe ให้ deploy `dist/` เดียวกันบน static HTTPS host และเปิด URL นั้นในแท็บใหม่เพื่อเชื่อม Wallet.
ตั้ง `VITE_EXTERNAL_GAME_URL` เป็น URL ดังกล่าวก่อน build เพื่อให้เกมสร้างลิงก์ fallback พร้อมนำลำดับการเดินไปยังแท็บใหม่อัตโนมัติ.
