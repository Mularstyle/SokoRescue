import './style.css';
import { BOARD_SIZE, GOAL, INITIAL_STATE, INTERNAL_WALLS, applyMove, samePosition, type GameState, type Move } from './game';
import { connectWallet, publicClient, readScores, submitSolution } from './contract';
import { getGrottoPlayerName } from './grotto';

let state: GameState = INITIAL_STATE;
let account: `0x${string}` | null = null;
const externalGameUrl = import.meta.env.VITE_EXTERNAL_GAME_URL as string | undefined;

const board = document.querySelector<HTMLDivElement>('#board')!;
const moveCount = document.querySelector<HTMLElement>('#move-count')!;
const status = document.querySelector<HTMLElement>('#status')!;
const walletLabel = document.querySelector<HTMLElement>('#wallet-label')!;
const submitButton = document.querySelector<HTMLButtonElement>('#submit-score')!;
const scorePanel = document.querySelector<HTMLElement>('#scores')!;

function render(): void {
  board.replaceChildren();
  for (let y = 0; y < BOARD_SIZE; y++) {
    for (let x = 0; x < BOARD_SIZE; x++) {
      const tile = document.createElement('div');
      const point = { x, y };
      tile.className = 'tile';
      if (x === 0 || y === 0 || x === 6 || y === 6 || INTERNAL_WALLS.some((wall) => samePosition(wall, point))) tile.classList.add('wall');
      if (samePosition(point, GOAL)) tile.classList.add('goal');
      if (samePosition(point, state.box)) tile.classList.add('box');
      if (samePosition(point, state.player)) tile.classList.add('player');
      board.append(tile);
    }
  }
  moveCount.textContent = String(state.moves);
  submitButton.disabled = !state.solved;
  status.textContent = state.solved ? 'Solved! บันทึกผลบน Avalanche ได้แล้ว' : 'ดันกล่องสีทองไปยังคริสตัล';
}

function move(direction: Move): void {
  const next = applyMove(state, direction);
  if (next === state) status.textContent = 'ทางนี้ไปไม่ได้';
  state = next;
  render();
}

document.querySelectorAll<HTMLButtonElement>('[data-move]').forEach((button) => {
  button.addEventListener('click', () => move(Number(button.dataset.move) as Move));
});

document.addEventListener('keydown', (event) => {
  const keys: Record<string, Move> = { ArrowUp: 0, ArrowRight: 1, ArrowDown: 2, ArrowLeft: 3 };
  if (event.key in keys) {
    event.preventDefault();
    move(keys[event.key]);
  }
});

document.querySelector('#reset')!.addEventListener('click', () => {
  state = INITIAL_STATE;
  scorePanel.textContent = '';
  render();
});

document.querySelector('#connect-wallet')!.addEventListener('click', async () => {
  try {
    account = await connectWallet();
    walletLabel.textContent = `${account.slice(0, 6)}…${account.slice(-4)}`;
    const scores = await readScores(account);
    scorePanel.textContent = `สถิติของคุณ: ${scores.personal || '—'} · สถิติโลก: ${scores.global || '—'} ก้าว`;
  } catch (error) {
    if (externalGameUrl && window.self !== window.top) {
      const url = new URL(externalGameUrl);
      url.searchParams.set('moves', state.history.join(','));
      scorePanel.innerHTML = `<a href="${url.toString()}" target="_blank" rel="noreferrer">เปิดเกมในแท็บใหม่เพื่อเชื่อม Core Wallet</a>`;
    }
    status.textContent = error instanceof Error ? error.message : 'เชื่อม Wallet ไม่สำเร็จ';
  }
});

submitButton.addEventListener('click', async () => {
  try {
    if (!account) account = await connectWallet();
    status.textContent = 'กรุณายืนยันธุรกรรมใน Core Wallet…';
    const hash = await submitSolution(state.history, account);
    status.textContent = 'กำลังรอ Avalanche ยืนยัน…';
    await publicClient.waitForTransactionReceipt({ hash });
    const scores = await readScores(account);
    scorePanel.innerHTML = `บันทึกแล้ว ${scores.personal} ก้าว · สถิติโลก ${scores.global} ก้าว · <a href="https://subnets-test.avax.network/c-chain/tx/${hash}" target="_blank" rel="noreferrer">ดูธุรกรรม</a>`;
    status.textContent = 'บันทึกผลบน Fuji สำเร็จ';
  } catch (error) {
    status.textContent = error instanceof Error ? error.message : 'ส่งผลไม่สำเร็จ';
  }
});

getGrottoPlayerName().then((name) => {
  document.querySelector<HTMLElement>('#player-name')!.textContent = name;
});

const sharedMoves = new URLSearchParams(location.search).get('moves');
if (sharedMoves) {
  try {
    state = sharedMoves.split(',').filter(Boolean).reduce((current, value) => applyMove(current, Number(value)), INITIAL_STATE);
  } catch {
    state = INITIAL_STATE;
  }
}

render();
