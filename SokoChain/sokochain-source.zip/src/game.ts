export type Position = Readonly<{ x: number; y: number }>;
export type Move = 0 | 1 | 2 | 3;

export type GameState = Readonly<{
  player: Position;
  box: Position;
  moves: number;
  history: readonly Move[];
  solved: boolean;
}>;

export const BOARD_SIZE = 7;
export const GOAL: Position = { x: 4, y: 2 };
export const INTERNAL_WALLS: readonly Position[] = [{ x: 2, y: 2 }, { x: 3, y: 2 }];
export const INITIAL_STATE: GameState = {
  player: { x: 1, y: 4 },
  box: { x: 3, y: 3 },
  moves: 0,
  history: [],
  solved: false,
};

const DELTAS: Record<Move, Position> = {
  0: { x: 0, y: -1 },
  1: { x: 1, y: 0 },
  2: { x: 0, y: 1 },
  3: { x: -1, y: 0 },
};

export function samePosition(a: Position, b: Position): boolean {
  return a.x === b.x && a.y === b.y;
}

export function isWall(position: Position): boolean {
  if (position.x === 0 || position.y === 0 || position.x === BOARD_SIZE - 1 || position.y === BOARD_SIZE - 1) return true;
  return INTERNAL_WALLS.some((wall) => samePosition(wall, position));
}

export function applyMove(state: GameState, move: number): GameState {
  if (!(move in DELTAS)) throw new Error('Invalid move');
  if (state.solved) return state;

  const delta = DELTAS[move as Move];
  const nextPlayer = { x: state.player.x + delta.x, y: state.player.y + delta.y };
  if (isWall(nextPlayer)) return state;

  let nextBox = state.box;
  if (samePosition(nextPlayer, state.box)) {
    const pushedBox = { x: state.box.x + delta.x, y: state.box.y + delta.y };
    if (isWall(pushedBox)) return state;
    nextBox = pushedBox;
  }

  return {
    player: nextPlayer,
    box: nextBox,
    moves: state.moves + 1,
    history: [...state.history, move as Move],
    solved: samePosition(nextBox, GOAL),
  };
}

export function replayMoves(moves: readonly number[]): GameState {
  return moves.reduce((state, move) => applyMove(state, move), INITIAL_STATE);
}
