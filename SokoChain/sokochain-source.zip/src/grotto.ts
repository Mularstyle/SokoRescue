type GrottoPlayer = { player?: { displayName?: string; walletAddress?: string } };

export async function getGrottoPlayerName(): Promise<string> {
  try {
    const runtime = await window.GrottoRuntime?.ready({ timeoutMs: 3000 });
    if (!runtime) return 'Guest Solver';
    const session = await runtime.getPlayer() as GrottoPlayer;
    return session.player?.displayName || 'Grotto Solver';
  } catch {
    return 'Guest Solver';
  }
}

declare global {
  interface Window {
    GrottoRuntime?: {
      ready: (options: { timeoutMs: number }) => Promise<{ getPlayer: () => Promise<unknown> }>;
    };
  }
}
